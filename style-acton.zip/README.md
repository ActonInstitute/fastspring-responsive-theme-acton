# FastSpring Responsive Theme

This is a responsive theme for the FastSpring eCommerce solution in order to sell products on mobile easily.  It was created primarily to sell digital products, but could be adapted easily for physical products.  The current branding is that of the Acton Institute, a non-profit think tank in Grand Rapids, MI.

A production demo: http://sites.fastspring.com/acton/product/actonuniversity2013